SELECT * FROM EMPLOYEE;

SELECT * FROM DEPARTMENT;

SELECT * FROM JOB;
SELECT * FROM LOCATION;

SELECT First_Name, Last_Name, Salary, Comm FROM EMPLOYEE;
SELECT Employe_ID AS [ID of the Employee], Last_Name AS [Name of the Employee], Department_ID AS Dep_id FROM EMPLOYEE;

SELECT Employe_ID AS [ID of the Employee], Last_Name AS [Name of the Employee], Department_ID AS Dep_id FROM EMPLOYEE;

SELECT * FROM EMPLOYEE WHERE Last_Name = 'Smith';

SELECT * FROM EMPLOYEE WHERE Department_ID = 20;

SELECT * FROM EMPLOYEE WHERE Salary BETWEEN 2000 AND 3000;

SELECT * FROM EMPLOYEE WHERE Department_ID IN (10,20);

SELECT * FROM EMPLOYEE WHERE Department_ID NOT IN (10,30);

SELECT * FROM EMPLOYEE WHERE First_Name LIKE 'L%';

SELECT * FROM EMPLOYEE WHERE First_Name LIKE 'L%E';

SELECT * FROM EMPLOYEE WHERE First_Name LIKE 'L%E';

SELECT * FROM EMPLOYEE WHERE Department_ID = 30 AND Salary > 2500;

SELECT * FROM EMPLOYEE WHERE Comm IS NULL;

SELECT Employe_ID, Last_Name FROM EMPLOYEE ORDER BY Employe_ID ASC;

SELECT Employe_ID, First_Name, Last_Name FROM EMPLOYEE ORDER BY Salary DESC;

SELECT Employe_ID, First_Name, Last_Name FROM EMPLOYEE ORDER BY Salary DESC;

SELECT Department_ID, MAX(Salary) AS MaxSalary, MIN(Salary) AS MinSalary, AVG(Salary) AS AvgSalary
FROM EMPLOYEE
GROUP BY Department_ID;

SELECT Job_ID, MAX(Salary) AS MaxSalary, MIN(Salary) AS MinSalary, AVG(Salary) AS AvgSalary
FROM EMPLOYEE
GROUP BY Job_ID;

SELECT MONTH(Hire_Date) AS Month, COUNT(*) AS NumEmployees
FROM EMPLOYEE
GROUP BY MONTH(Hire_Date)
ORDER BY Month ASC;

SELECT YEAR(Hire_Date) AS Year, MONTH(Hire_Date) AS Month, COUNT(*) AS NumEmployees
FROM EMPLOYEE
GROUP BY YEAR(Hire_Date), MONTH(Hire_Date)
ORDER BY Year ASC, Month ASC;

SELECT Department_ID
FROM EMPLOYEE
GROUP BY Department_ID
HAVING COUNT(*) >= 4;

SELECT COUNT(*) AS NumEmployees
FROM EMPLOYEE
WHERE MONTH(Hire_Date) = 2;

SELECT COUNT(*) AS NumEmployees
FROM EMPLOYEE
WHERE MONTH(Hire_Date) IN (5,6);

SELECT COUNT(*) AS NumEmployees
FROM EMPLOYEE
WHERE YEAR(Hire_Date) = 1985;

SELECT MONTH(Hire_Date) AS Month, COUNT(*) AS NumEmployees
FROM EMPLOYEE
WHERE YEAR(Hire_Date) = 1985
GROUP BY MONTH(Hire_Date)
ORDER BY Month ASC;


SELECT COUNT(*) AS NumEmployees
FROM EMPLOYEE
WHERE YEAR(Hire_Date) = 1985 AND MONTH(Hire_Date) = 4;


SELECT Department_ID
FROM EMPLOYEE
WHERE YEAR(Hire_Date) = 1985 AND MONTH(Hire_Date) = 4
GROUP BY Department_ID
HAVING COUNT(*) >= 3;

SELECT E.*, D.Name AS DepartmentName
FROM EMPLOYEE E
JOIN DEPARTMENT D ON E.Department_ID = D.Department_Id;

SELECT E.*, J.Designation
FROM EMPLOYEE E
JOIN JOB J ON E.Job_ID = J.Job_ID;

SELECT E.*, D.Name AS DepartmentName, L.City
FROM EMPLOYEE E
JOIN DEPARTMENT D ON E.Department_ID = D.Department_Id
JOIN LOCATION L ON D.Location_Id = L.Location_ID;

SELECT D.Name, COUNT(E.Employe_ID) AS NumEmployees
FROM DEPARTMENT D
LEFT JOIN EMPLOYEE E ON D.Department_Id = E.Department_ID
GROUP BY D.Name;


SELECT COUNT(*) AS NumEmployees
FROM EMPLOYEE E
JOIN DEPARTMENT D ON E.Department_ID = D.Department_Id
WHERE D.Name = 'Sales';

SELECT D.Name
FROM DEPARTMENT D
JOIN EMPLOYEE E ON D.Department_Id = E.Department_ID
GROUP BY D.Name
HAVING COUNT(E.Employe_ID) >= 3
ORDER BY D.Name ASC;

SELECT COUNT(*) AS NumEmployees
FROM EMPLOYEE E
JOIN DEPARTMENT D ON E.Department_ID = D.Department_Id
JOIN LOCATION L ON D.Location_Id = L.Location_ID
WHERE L.City = 'Dallas';

SELECT E.*
FROM EMPLOYEE E
JOIN DEPARTMENT D ON E.Department_ID = D.Department_Id
WHERE D.Name IN ('Sales', 'Operations');

SELECT *,
  CASE
    WHEN Salary BETWEEN 1000 AND 1999 THEN 'A'
    WHEN Salary BETWEEN 2000 AND 2999 THEN 'B'
    WHEN Salary >= 3000 THEN 'C'
    ELSE 'D'
  END AS Grade
FROM EMPLOYEE;

SELECT
  CASE
    WHEN Salary BETWEEN 1000 AND 1999 THEN 'A'
    WHEN Salary BETWEEN 2000 AND 2999 THEN 'B'
    WHEN Salary >= 3000 THEN 'C'
    ELSE 'D'
  END AS Grade,
  COUNT(*) AS NumEmployees
FROM EMPLOYEE
GROUP BY
  CASE
    WHEN Salary BETWEEN 1000 AND 1999 THEN 'A'
    WHEN Salary BETWEEN 2000 AND 2999 THEN 'B'
    WHEN Salary >= 3000 THEN 'C'
    ELSE 'D'
  END;

  SELECT
  CASE
    WHEN Salary BETWEEN 2000 AND 2999 THEN 'B'
    WHEN Salary >= 3000 THEN 'C'
    ELSE 'D'
  END AS Grade,
  COUNT(*) AS NumEmployees
FROM EMPLOYEE
WHERE Salary BETWEEN 2000 AND 5000
GROUP BY
  CASE
    WHEN Salary BETWEEN 2000 AND 2999 THEN 'B'
    WHEN Salary >= 3000 THEN 'C'
    ELSE 'D'
  END;


SELECT * FROM EMPLOYEE WHERE Salary = (SELECT MAX(Salary) FROM EMPLOYEE);

SELECT * FROM EMPLOYEE WHERE Department_ID = (SELECT Department_Id FROM DEPARTMENT WHERE Name = 'Sales');


SELECT * FROM EMPLOYEE WHERE Job_ID = (SELECT Job_ID FROM JOB WHERE Designation = 'Clerk');

SELECT * FROM EMPLOYEE
WHERE Department_ID IN (
  SELECT Department_Id FROM DEPARTMENT WHERE Location_Id = (SELECT Location_ID FROM LOCATION WHERE City = 'Boston')
);

SELECT COUNT(*) FROM EMPLOYEE WHERE Department_ID = (SELECT Department_Id FROM DEPARTMENT WHERE Name = 'Sales');


UPDATE EMPLOYEE
SET Salary = Salary * 1.10
WHERE Job_ID = (SELECT Job_ID FROM JOB WHERE Designation = 'Clerk');

SELECT * FROM EMPLOYEE
WHERE Salary = (
  SELECT MAX(Salary) FROM EMPLOYEE WHERE Salary < (SELECT MAX(Salary) FROM EMPLOYEE)
);

SELECT * FROM EMPLOYEE
WHERE Salary > ALL (SELECT Salary FROM EMPLOYEE WHERE Department_ID = 30);

SELECT Department_Id FROM DEPARTMENT WHERE Department_Id NOT IN (SELECT Department_ID FROM EMPLOYEE);

SELECT * FROM EMPLOYEE E
WHERE Salary > (
  SELECT AVG(Salary) FROM EMPLOYEE WHERE Department_ID = E.Department_ID
);






